import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Swiat.*;
import Swiat.Zwierzeta.Czlowiek;

public class App {

    public static class GameData {
        protected Button butt;
        protected Boolean isFree;
        protected Organizm Organi;

        public GameData(Organizm or, Button btn) {
            Organi = or;
            butt = btn;
            isFree = false;
        }

        public Boolean getIsFree() {
            return isFree;
        }

        public void setIsFree(Boolean t) {
            isFree = t;
        }
    }

    // public void PlayerMove(KeyEvent arg0){
    // switch (arg0.getkeyCode())
    // case VK_UP
    // Czlowiek.SetPolozenie(GetPolozenie[0]+1)
    // ;
    // case VK_DOWN
    // Czlowiek.SetPolozenie(GetPolozenie[0]-1)
    // ;
    // case VK_RIGHT
    // Czlowiek.SetPolozenie(GetPolozenie[1]+1)
    // ;
    // case VK_LEFT
    // Czlowiek.SetPolozenie(GetPolozenie[1]-1)
    // ;
    // case VK_ESCAPE
    // ;
    // }

    public static void main(String[] args) {
        JFrame frame = new JFrame();
        ArrayList<GameData> t = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            Button tmp = new Button("bnt " + i);
            int[] tks = { 0, 1 };
            Organizm czl = new Czlowiek(5, 4, tks);
            GameData tmp2 = new GameData(czl, tmp);
            frame.add(tmp);
            t.add(tmp2);
        }
        t.forEach(r -> {
            System.out.println(r.getIsFree());
        });
        frame.setLayout(new GridLayout(10, 10));
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        frame.setSize(800, 800);
        frame.setLocationRelativeTo(null); // center
        frame.setVisible(true);
    }
}