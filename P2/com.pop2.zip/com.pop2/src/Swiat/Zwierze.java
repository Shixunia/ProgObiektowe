package Swiat;

public class Zwierze extends Organizm {
    public Zwierze(int s, int i, int[] p, String name) {
        super(s, i, p, name);
    }
}
