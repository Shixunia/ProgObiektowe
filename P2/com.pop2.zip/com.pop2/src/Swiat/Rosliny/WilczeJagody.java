package Swiat.Rosliny;

import Swiat.Roslina;

public class WilczeJagody extends Roslina {
    // zwierze ginie jak zje
}
