package Swiat.Rosliny;

import Swiat.Roslina;

public class Guarana extends Roslina {
    // kolizja -> +3 do sily
}
