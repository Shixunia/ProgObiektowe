package Swiat.Rosliny;

import Swiat.Roslina;

public class BarszczSosnowskiego extends Roslina {
    // akcja() -> zabija zwierzeta w oklicy
    // kolizja() -> zwierze ginie
}
