package Swiat.Rosliny;

import Swiat.Roslina;

public class Mlecz extends Roslina {
    // trzy proby rozprzestrzeniania sie w turze
}
