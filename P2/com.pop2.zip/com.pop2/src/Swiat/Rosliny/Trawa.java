package Swiat.Rosliny;

import Swiat.Roslina;

public class Trawa extends Roslina {
    // nic
}
