package Swiat;

public abstract class Organizm {
    private int Sila;
    private int Inicjatywa;
    private int[] Polozenie;
    private String nazwa;
    Swiat AktualnySwiat;

    public Organizm(int s, int i, int[] p, String name) {
        setSila(s);
        setInicjatywa(i);
        this.setPolozenie(p);
        this.nazwa = name;
    }

    public String getName() {
        return nazwa;
    }

    public int getSila() {
        return Sila;
    }

    public void setSila(int sila) {
        this.Sila = sila;
    }

    public int getInicjatywa() {
        return Inicjatywa;
    }

    public void setInicjatywa(int inicjatywa) {
        this.Inicjatywa = inicjatywa;
    }

    public int[] getPolozenie() {
        return Polozenie;
    }

    public void setPolozenie(int[] polozenie) {
        this.Polozenie = polozenie;
    }

    public int[] Akcja() {
        int[] act = getPolozenie();
        // random pozycja obok
        return act;
    }
}
