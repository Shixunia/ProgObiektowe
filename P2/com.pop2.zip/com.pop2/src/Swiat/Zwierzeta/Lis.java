package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Lis extends Zwierze {
    Lis(int s, int i, int[] p) {
        super(s, i, p, "L");
    }
}
