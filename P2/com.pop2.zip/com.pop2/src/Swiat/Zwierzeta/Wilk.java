package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Wilk extends Zwierze {
    Wilk(int s, int i, int[] p) {
        super(s, i, p, "W");
    }

    @Override
    public int[] Akcja() {
        int[] t = getPolozenie();
        // Dobry węch: lis nigdy nie ruszy się na pole zajmowane przez organizm
        // silniejszy niż on
        return t;
    }
}
