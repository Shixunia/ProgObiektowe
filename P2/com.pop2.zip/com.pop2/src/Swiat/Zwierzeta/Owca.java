package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Owca extends Zwierze {
    Owca(int s, int i, int[] p) {
        super(s, i, p, "O");
    }
}
