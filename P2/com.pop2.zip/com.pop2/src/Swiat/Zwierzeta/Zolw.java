package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Zolw extends Zwierze {
    Zolw(int s, int i, int[] p) {
        super(s, i, p, "Z");
    }

    @Override
    public int[] Akcja() {
        int[] t = getPolozenie();
        // W 75% przypadków nie zmienia swojego położenia.
        return t;
    }
}
