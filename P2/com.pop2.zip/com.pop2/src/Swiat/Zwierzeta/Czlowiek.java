package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Czlowiek extends Zwierze {
    public Czlowiek(int s, int i, int[] p) {
        super(s, i, p, "+");
    }
}
// Człowiek nie może zostać zabity. W przypadku
// konfrontacji z silniejszym przeciwnikiem przesuwa się
// na losowo wybrane pole sąsiadujące.
