package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Antylopa extends Zwierze {
    Antylopa(int s, int i, int[] p) {
        super(s, i, p, "A");
    }

    @Override
    public int[] Akcja() {
        int[] t = getPolozenie();
        // Zasięg ruchu wynosi 2 pola.
        return t;
    }
}
