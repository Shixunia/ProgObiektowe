package Swiat;

import java.util.ArrayList;
import java.util.List;

public class Swiat {
    private List<Organizm> Organizmy = new ArrayList<>();

    public void AddOrganizm(Organizm t) {
        Organizmy.add(t);
    }

    public void CreateWord() {

    }

    public void DoActions() {
        Organizmy.forEach(org -> {
            org.Akcja();
        });
    }
}
