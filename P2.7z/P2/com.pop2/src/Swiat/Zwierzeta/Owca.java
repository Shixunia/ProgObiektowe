package Swiat.Zwierzeta;

import Swiat.Zwierze;

public class Owca extends Zwierze {
    public Owca() {
        super(4, 4, "O");
    }
}
